(function DiscordSend() {
    if (!Spicetify.CosmosAsync || !Spicetify.ContextMenu || !Spicetify.URI) {
        setTimeout(DiscordSend, 300);
        return;
    }

    // Конфигурация (ЗАМЕНИТЕ НА СВОИ!)
    const DISCORD_USER_TOKEN = "MjI3MTExNjk5MTkzMjY2MTc2.GwBL2b.lsAZRSLH57uAkKiLPIAXUMIErxAjgE5YBPmwfA"; // Токен пользователя
    const DISCORD_CHANNEL_ID = "1344253784263622746"; // ID канала

    async function sendToDiscord(uri) {
        try {
            // Проверяем URI трека
            const parsed = Spicetify.URI.fromString(uri);
            if (!parsed || parsed.type !== Spicetify.URI.Type.TRACK) return false;

            // Получаем данные трека
            const track = await Spicetify.CosmosAsync.get(
                `https://api.spotify.com/v1/tracks/${parsed.id}`
            );
            const link = `https://open.spotify.com/track/${track.id}`;

            // Формируем сообщение в формате "m!play ссылка_на_трек"
            const message = `m!play ${link}`;

            // Отправляем сообщение через Discord API
            const response = await fetch(
                `https://discord.com/api/v9/channels/${DISCORD_CHANNEL_ID}/messages`,
                {
                    method: "POST",
                    headers: {
                        "Authorization": DISCORD_USER_TOKEN,
                        "Content-Type": "application/json",
                        "Origin": "https://discord.com" // Обход CORS
                    },
                    body: JSON.stringify({ content: message })
                }
            );

            return response.ok;
        } catch (error) {
            console.error("Discord Error:", error);
            return false;
        }
    }

    // Добавляем кнопку в контекстное меню
    new Spicetify.ContextMenu.Item(
        "Send to Discord",
        async (uris) => {
            const success = await sendToDiscord(uris[0]);
            Spicetify.showNotification(
                success ? "Sent to Discord!" : "Failed to send!",
                !success
            );
        },
        (uris) => uris.length === 1 && Spicetify.URI.isTrack(uris[0]),
        "link" // Иконка
    ).register();
})();